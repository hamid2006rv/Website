pwt.datepicker
==============

Jalali calendar datepicker, which depends on https://github.com/babakhani/PersianDate

[Documents](http://babakhani.github.io/PersianWebToolkit/datepicker)


persian, datepicker, date, khayam, jalali, jquery, plugin, javascript, js, persian web toolkit, pwt,
bootstrap timepicker, bootstrap datetimepicker

